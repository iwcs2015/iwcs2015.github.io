/*****************************
 * Jeroen Bransen            *
 * Jeroen.Bransen@phil.uu.nl *
 * Master's Thesis           *
 * Utrecht University        *
 * May 2010                  *
 *****************************/
#ifndef TOTERM_H
#define TOTERM_H

#include "Representation.h"
#include <map>
#include <vector>

using namespace std;

/* List of mapping from binary connectives to Term */
map<BINARY_CONNECTIVE,char*> createBinaryToTerm() 
{ 
	map<BINARY_CONNECTIVE,char*> m;
	m[BACKSLASH] = "backslash";
	m[SLASH] = "slash";
	m[OTIMES] = "otimes";
	m[OSLASH] = "oslash";
	m[OBACKSLASH] = "obslash";
	m[OPLUS] = "oplus";
	return m; 
}
map<BINARY_CONNECTIVE,char*> binaryToTerm = createBinaryToTerm();

/* Print unary connectives to Term */
void toTermUnary(FILE *fout, UNARY_CONNECTIVE connective, bool prefix, bool structural) {
	if(connective == ONE || connective == ZERO)
		fprintf(fout, "%c%s%ceg", prefix ? 'l' : 'r', connective == ONE ? "d" : "", structural ? 'N' : 'n');
}

/* Print Term representation of formula to fout */
void toTermFormula(FILE *fout, Formula *formula, bool top) {
	switch(formula->type) {
		/* Literal */
		case PRIMITIVE:
			fprintf(fout, "lit(%s)", formula->name);
			if(SHOW_PRIMITIVE_INDEX && formula->literal_index > -1)
				fprintf(fout, "_{%d}", formula->literal_index);
			break;
		/* Binary connective */
		case BINARY:
			if(!top)
				fprintf(fout, "");
			fprintf(fout, binaryToTerm[formula->binary_connective]);
			fprintf(fout, ",");
			toTermFormula(fout, formula->left, false);
			fprintf(fout, ",");
			toTermFormula(fout, formula->right, false);
			if(!top)
				fprintf(fout, "");
			break;
		/* Unary */
		case UNARY:
			if(!top)
				fprintf(fout, "");
			toTermUnary(fout, formula->unary_connective, formula->prefix, false);
			fprintf(fout, ",");
			toTermFormula(fout, formula->inner, false);
			fprintf(fout, "");
			if(!top)
				fprintf(fout, "");
			break;
		/* Match */
		case MATCH:
			fprintf(fout, "%c", formula->matchChar);
			break;
	}
}

/* Print Term representation of structure to fout */
void toTermStructure(FILE *fout, Structure *structure, bool top) {
	switch(structure->type) {
		/* Primitive */
		case PRIMITIVE:
			if(top)
				fprintf(fout, "");
			toTermFormula(fout, structure->formula, false);
			if(top)
				fprintf(fout, "");
			break;
		/* Binary connective */
		case BINARY:
			if(!top)
				fprintf(fout, "");
			fprintf(fout, "str_%s", binaryToTerm[structure->binary_connective]);
			fprintf(fout, ",");
			toTermStructure(fout, structure->left, false);
			fprintf(fout, ",");
			toTermStructure(fout, structure->right, false);
			if(!top)
				fprintf(fout, "");
			break;
		/* Unary */
		case UNARY:
			if(!top)
				fprintf(fout, "");
			toTermUnary(fout, structure->unary_connective, structure->prefix, true);
			fprintf(fout, ",");
			toTermStructure(fout, structure->inner, false);
			fprintf(fout, "");
			if(!top)
				fprintf(fout, "");
			break;
		/* Match */
		case MATCH:
			fprintf(fout, "%c", structure->matchChar);
			break;
	}
}

/* Print Term representation of sequent to fout */
void toTermSequent(FILE *fout, Sequent *sequent) {
	switch(sequent->type) {
		/* Formula left */
		case FORMULA_LEFT:
			fprintf(fout, "vdashleft,");
			toTermFormula(fout, sequent->leftF, true);
			fprintf(fout, ",");
			toTermStructure(fout, sequent->rightS, true);
			break;
		/* Formula right */
		case FORMULA_RIGHT:
			fprintf(fout, "vdashright,");
			toTermStructure(fout, sequent->leftS, true);
			fprintf(fout, ",");
			toTermFormula(fout, sequent->rightF, true);
			break;
		/* Structural */
		case STRUCTURAL:
			fprintf(fout, "vdash,");
			toTermStructure(fout, sequent->leftS, true);
			fprintf(fout, ",");
			toTermStructure(fout, sequent->rightS, true);
			break;	
	}
}

/* Return the name for this proofbox */
char* toTermProofboxName(int proofBoxNum) {
	char *s = new char[10];
	int i = 0;
	do {
		s[i] = 'a' + (proofBoxNum % 26);
		proofBoxNum /= 26;
		i++;
	} while(proofBoxNum);
	s[i] = 0;
	return s;
}

/* Print Term representation of derivation to fout */
void toTermDerivation(FILE *fout, Derivation *derivation) {
	fprintf(fout, "infer,name('%s'),", derivation->rule->TermName);
	toTermSequent(fout, derivation->conclusion);
	fprintf(fout, ",from");
	for(int i = 0; i < derivation->numPremisses; i++) {
		if(i > 0) {
			fprintf(fout, ",and");
		}
		fprintf(fout, ",");
		toTermDerivation(fout, derivation->premisses[i]);
		fprintf(fout, "");
	}
	fprintf(fout, "");
}

/* Print Term representation of derivation to fout in a proofbox */
void toTermDerivation(FILE *fout, Derivation *derivation, int proofBoxNum, int numConnectives) {
	char *boxName = toTermProofboxName(proofBoxNum);
	fprintf(fout, "proof(%s,[", boxName);
	toTermDerivation(fout, derivation);
	fprintf(fout, "]).\n");
}

/* Print Term header to fout */
void toTermHeader(FILE *fout) {
	fprintf(fout, "/* Start derivations */\n");
}

/* Print Term footer to fout */
void toTermFooter(FILE *fout, int numBoxes) {
	fprintf(fout, "/* End derivations */\n");
}

/* Show this derivation as Term */
void toTermShowDerivation(Derivation *derivation, int numConnectives) {
	/* Write Term to file */
	FILE *fout = fopen("lgterm.pl", "w");
	toTermHeader(fout);
	toTermDerivation(fout, derivation, 0, numConnectives);
	toTermFooter(fout, 1);
	fclose(fout);

	/* Call pdfTerm to parse and show */
	system("more lgterm.pl");
}

/* Show this derivation as Term */
void toTermShowDerivations(vector<Derivation *> derivations, int numConnectives) {
	/* Write Term to file */
	FILE *fout = fopen("lgterm.pl", "w");
	toTermHeader(fout);
	for(unsigned int i = 0; i < derivations.size(); i++)
		toTermDerivation(fout, derivations[i], i, numConnectives);
	toTermFooter(fout, derivations.size());
	fclose(fout);

	/* Call pdfTerm to parse and show */
	system("more lgterm.pl");
}

#endif
