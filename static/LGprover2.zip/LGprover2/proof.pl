form(np) --> "np".
form(s) --> "s".

form(otimes(A,B)) --> form(A),"\cdot\otimes\cdot",form(B).

